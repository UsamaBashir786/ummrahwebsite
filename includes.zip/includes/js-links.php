
<script src="assets/bootstrap-5.2.3-dist/js/bootstrap.bundle.js"></script>